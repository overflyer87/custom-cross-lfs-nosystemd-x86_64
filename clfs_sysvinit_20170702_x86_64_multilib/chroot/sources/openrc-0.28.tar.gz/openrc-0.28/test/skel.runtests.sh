#!/bin/sh

# top_srcdir=${top_srcdir:-SET/THIS/PATH/OK!?}
. ${top_srcdir}/test/setup_env.sh

