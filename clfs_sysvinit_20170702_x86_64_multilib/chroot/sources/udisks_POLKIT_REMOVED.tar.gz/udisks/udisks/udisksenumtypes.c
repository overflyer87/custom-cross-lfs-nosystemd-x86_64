
/* Generated data (by glib-mkenums) */

#include "udisksenums.h"
#include "udisksenumtypes.h"

/* enumerations from "udisksenums.h" */
GType
udisks_error_get_type (void)
{
  static volatile gsize g_define_type_id__volatile = 0;

  if (g_once_init_enter (&g_define_type_id__volatile))
    {
      static const GEnumValue values[] = {
        { UDISKS_ERROR_FAILED, "UDISKS_ERROR_FAILED", "failed" },
        { UDISKS_ERROR_CANCELLED, "UDISKS_ERROR_CANCELLED", "cancelled" },
        { UDISKS_ERROR_ALREADY_CANCELLED, "UDISKS_ERROR_ALREADY_CANCELLED", "already-cancelled" },
        { UDISKS_ERROR_NOT_AUTHORIZED, "UDISKS_ERROR_NOT_AUTHORIZED", "not-authorized" },
        { UDISKS_ERROR_NOT_AUTHORIZED_CAN_OBTAIN, "UDISKS_ERROR_NOT_AUTHORIZED_CAN_OBTAIN", "not-authorized-can-obtain" },
        { UDISKS_ERROR_NOT_AUTHORIZED_DISMISSED, "UDISKS_ERROR_NOT_AUTHORIZED_DISMISSED", "not-authorized-dismissed" },
        { UDISKS_ERROR_ALREADY_MOUNTED, "UDISKS_ERROR_ALREADY_MOUNTED", "already-mounted" },
        { UDISKS_ERROR_NOT_MOUNTED, "UDISKS_ERROR_NOT_MOUNTED", "not-mounted" },
        { UDISKS_ERROR_OPTION_NOT_PERMITTED, "UDISKS_ERROR_OPTION_NOT_PERMITTED", "option-not-permitted" },
        { UDISKS_ERROR_MOUNTED_BY_OTHER_USER, "UDISKS_ERROR_MOUNTED_BY_OTHER_USER", "mounted-by-other-user" },
        { UDISKS_ERROR_ALREADY_UNMOUNTING, "UDISKS_ERROR_ALREADY_UNMOUNTING", "already-unmounting" },
        { UDISKS_ERROR_NOT_SUPPORTED, "UDISKS_ERROR_NOT_SUPPORTED", "not-supported" },
        { UDISKS_ERROR_TIMED_OUT, "UDISKS_ERROR_TIMED_OUT", "timed-out" },
        { UDISKS_ERROR_WOULD_WAKEUP, "UDISKS_ERROR_WOULD_WAKEUP", "would-wakeup" },
        { UDISKS_ERROR_DEVICE_BUSY, "UDISKS_ERROR_DEVICE_BUSY", "device-busy" },
        { UDISKS_ERROR_ISCSI_DAEMON_TRANSPORT_FAILED, "UDISKS_ERROR_ISCSI_DAEMON_TRANSPORT_FAILED", "iscsi-daemon-transport-failed" },
        { UDISKS_ERROR_ISCSI_HOST_NOT_FOUND, "UDISKS_ERROR_ISCSI_HOST_NOT_FOUND", "iscsi-host-not-found" },
        { UDISKS_ERROR_ISCSI_IDMB, "UDISKS_ERROR_ISCSI_IDMB", "iscsi-idmb" },
        { UDISKS_ERROR_ISCSI_LOGIN_FAILED, "UDISKS_ERROR_ISCSI_LOGIN_FAILED", "iscsi-login-failed" },
        { UDISKS_ERROR_ISCSI_LOGIN_AUTH_FAILED, "UDISKS_ERROR_ISCSI_LOGIN_AUTH_FAILED", "iscsi-login-auth-failed" },
        { UDISKS_ERROR_ISCSI_LOGIN_FATAL, "UDISKS_ERROR_ISCSI_LOGIN_FATAL", "iscsi-login-fatal" },
        { UDISKS_ERROR_ISCSI_LOGOUT_FAILED, "UDISKS_ERROR_ISCSI_LOGOUT_FAILED", "iscsi-logout-failed" },
        { UDISKS_ERROR_ISCSI_NO_FIRMWARE, "UDISKS_ERROR_ISCSI_NO_FIRMWARE", "iscsi-no-firmware" },
        { UDISKS_ERROR_ISCSI_NO_OBJECTS_FOUND, "UDISKS_ERROR_ISCSI_NO_OBJECTS_FOUND", "iscsi-no-objects-found" },
        { UDISKS_ERROR_ISCSI_NOT_CONNECTED, "UDISKS_ERROR_ISCSI_NOT_CONNECTED", "iscsi-not-connected" },
        { UDISKS_ERROR_ISCSI_TRANSPORT_FAILED, "UDISKS_ERROR_ISCSI_TRANSPORT_FAILED", "iscsi-transport-failed" },
        { UDISKS_ERROR_ISCSI_UNKNOWN_DISCOVERY_TYPE, "UDISKS_ERROR_ISCSI_UNKNOWN_DISCOVERY_TYPE", "iscsi-unknown-discovery-type" },
        { 0, NULL, NULL }
      };
      GType g_define_type_id =
        g_enum_register_static (g_intern_static_string ("UDisksError"), values);
      g_once_init_leave (&g_define_type_id__volatile, g_define_type_id);
    }

  return g_define_type_id__volatile;
}

GType
udisks_partition_type_info_flags_get_type (void)
{
  static volatile gsize g_define_type_id__volatile = 0;

  if (g_once_init_enter (&g_define_type_id__volatile))
    {
      static const GFlagsValue values[] = {
        { UDISKS_PARTITION_TYPE_INFO_FLAGS_NONE, "UDISKS_PARTITION_TYPE_INFO_FLAGS_NONE", "none" },
        { UDISKS_PARTITION_TYPE_INFO_FLAGS_SWAP, "UDISKS_PARTITION_TYPE_INFO_FLAGS_SWAP", "swap" },
        { UDISKS_PARTITION_TYPE_INFO_FLAGS_RAID, "UDISKS_PARTITION_TYPE_INFO_FLAGS_RAID", "raid" },
        { UDISKS_PARTITION_TYPE_INFO_FLAGS_HIDDEN, "UDISKS_PARTITION_TYPE_INFO_FLAGS_HIDDEN", "hidden" },
        { UDISKS_PARTITION_TYPE_INFO_FLAGS_CREATE_ONLY, "UDISKS_PARTITION_TYPE_INFO_FLAGS_CREATE_ONLY", "create-only" },
        { UDISKS_PARTITION_TYPE_INFO_FLAGS_SYSTEM, "UDISKS_PARTITION_TYPE_INFO_FLAGS_SYSTEM", "system" },
        { 0, NULL, NULL }
      };
      GType g_define_type_id =
        g_flags_register_static (g_intern_static_string ("UDisksPartitionTypeInfoFlags"), values);
      g_once_init_leave (&g_define_type_id__volatile, g_define_type_id);
    }

  return g_define_type_id__volatile;
}


/* Generated data ends here */

