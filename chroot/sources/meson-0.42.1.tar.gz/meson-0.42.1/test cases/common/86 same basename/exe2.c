int func();

int main(int argc, char **argv) {
    return func() == 1 ? 0 : 1;
}
