#include<stdio.h>

int main(int argc, char **argv) {
    printf("I am myexe.\n");
    return 0;
}
