#include "func.h"

int main(int argc, char **argv) {
    return func();
}
