#include"myheader.lh"

int main(int argc, char **argv) {
    return RET_VAL;
}
