#include"data.h"

int main(int, char **) {
    return generated_function() != 52;
}
