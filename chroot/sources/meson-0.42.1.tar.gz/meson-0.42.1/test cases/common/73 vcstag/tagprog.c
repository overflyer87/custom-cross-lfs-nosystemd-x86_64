#include<stdio.h>

const char *vcstag;

int main(int argc, char **argv) {
    printf("Version is %s\n", vcstag);
    return 0;
}

