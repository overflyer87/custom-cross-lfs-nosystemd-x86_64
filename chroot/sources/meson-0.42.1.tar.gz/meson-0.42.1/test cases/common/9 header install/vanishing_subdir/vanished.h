#pragma once

/* This is a header in a subdirectory. Make sure it installs into
 * /prefix/include and not /prefix/include/vanishing_subdir.
 */
