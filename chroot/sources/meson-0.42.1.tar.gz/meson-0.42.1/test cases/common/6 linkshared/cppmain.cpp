int cppfunc();

int main(int argc, char **argv) {
    return cppfunc() != 42;
}
