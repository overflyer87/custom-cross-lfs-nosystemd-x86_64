#include"simple.h"

int simple_function() {
    return 42;
}
