/* Simple prog that sleeps for a random time. */

#include<stdlib.h>
#include<time.h>
#if defined(_WIN32)
#include<windows.h>
#endif

int main(int argc, char **argv) {
    srand(time(NULL));
#if !defined(_WIN32)
    struct timespec t;
    t.tv_sec = 0;
    t.tv_nsec = 199999999.0*rand()/RAND_MAX;
    nanosleep(&t, NULL);
#else
    Sleep(50.0*rand()/RAND_MAX);
#endif
    return 0;
}
