#include<subdefs.h>

int DLL_PUBLIC subfunc() {
    return 42;
}
