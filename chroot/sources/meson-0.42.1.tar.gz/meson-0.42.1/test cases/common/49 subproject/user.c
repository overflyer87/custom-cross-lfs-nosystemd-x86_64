#include<subdefs.h>
#include<stdio.h>


int main(int argc, char **argv) {
    int res;
    printf("Calling into sublib now.\n");
    res = subfunc();
    if(res == 42) {
        printf("Everything is fine.\n");
        return 0;
    } else {
        printf("Something went wrong.\n");
        return 1;
    }
}
