#include <stdio.h>

#include "../lib.h"

int get_st1_value (void);
int get_st2_value (void);
int get_st3_value (void);

int main(int argc, char *argv[]) {
  int val;

  val = get_st1_value ();
  if (val != 5) {
    printf("st1 value was %i instead of 5\n", val);
    return -1;
  }
  val = get_st2_value ();
  if (val != 4) {
    printf("st2 value was %i instead of 4\n", val);
    return -2;
  }
  val = get_st3_value ();
  if (val != 3) {
    printf("st3 value was %i instead of 3\n", val);
    return -3;
  }
  return 0;
}
