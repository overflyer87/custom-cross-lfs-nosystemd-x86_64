int libfunc2() {
    return 4;
}
